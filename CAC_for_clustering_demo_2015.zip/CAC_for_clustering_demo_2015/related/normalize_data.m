function fea=normalize_data(fea,method)
[n,m]=size(fea);
switch method
    case 1 %square
        fea00=sqrt(sum(fea.^2,2));
        for datai=1:n
            fea(datai,:)= fea(datai,:)/fea00(datai);
        end
    case 2%maxvalue
        fea=fea/max(max(abs(fea)));
    case 3 %
        for datai=1: n
            fea(datai,:)= fea(datai,:)/max( fea(datai,:));
        end
    case 4 %
        for datai=1: n
            fea(datai,:)= fea(datai,:)/sum( fea(datai,:));
        end
end

