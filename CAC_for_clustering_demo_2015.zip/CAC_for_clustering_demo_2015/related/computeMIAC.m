function [MIhat,AC]=computeMIAC(gnd,V,nClass)
rand('twister',5489);
label = litekmeans(V,nClass,'Replicates',20);%,'Distance','cosine');%�ظ�20��k-means
MIhat = MutualInfo(gnd,label);
% MIhat = MutualInfo1(gnd,label);
% disp(['Clustering in the NMF subspace. MIhat ',num2str(MIhat)]);
[~,Xn]=size(V');
for i=1:20 %k-means �ظ�20�࣬ȡ���ֵ����CNMF������-Ҫ�����
%     mincenter= kmeans(V,nClass);
    [~,mincenter]= kmeans1(V,nClass);%V:rows-points,coloumns-variables,n*k
    [newL2] = bestMap(gnd,mincenter);
    AC_t(i)=sum((newL2-gnd)==0)/Xn;
end
AC=max(AC_t);