[s11m,s11n]=sort(gnd);%
gnd=s11m;
fea=fea(s11n,:);
%%
[gnd1,gnd2]=unique(gnd);%
tempforcn= ceil(tabulate(gnd));
en=tempforcn(:,2);%
[gm0,gn0]=size(gnd2);
if gm0==1
    ccn=[0,gnd2];%
end
if gn0==1
    ccn=[0;gnd2];%
end
X=fea';[m,n]=size(X);Xn=n;